package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.OverallRiskLevel
import com.example.engine.HeuristicEngine
import com.example.engine.RemoteAccessAnalyzer
import com.example.engine.TextPatternAnalyzer
import com.example.engine.UrlAnalyzer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("CyberRaksha", appName)
    }

    @Test
    fun `heuristic engine flags IP based URL and power cut scare`() {
        val sample = "Dear Consumer, your electricity power will be disconnected tonight at 9:30 PM. Pay at http://192.168.1.55:8080/ebill-pay"
        val result = HeuristicEngine.analyze(sample)

        assertTrue(result.riskScore >= 70)
        assertTrue(result.riskLevel == OverallRiskLevel.HIGH || result.riskLevel == OverallRiskLevel.CRITICAL)
        assertTrue(result.findings.any { it.ruleId == "URL_IP_BASED" })
    }

    @Test
    fun `heuristic engine flags spoofed bank and apk download`() {
        val sample = "SBI Alert: Your YONO account blocked. Download SBI-Verify.apk from http://sbi-kyc-update.xyz/login"
        val result = HeuristicEngine.analyze(sample)

        assertTrue(result.riskScore >= 80)
        assertTrue(result.findings.any { it.ruleId == "URL_DIRECT_APK_PAYLOAD" || it.ruleId == "URL_RISKY_TLD" || it.ruleId == "TEXT_APK_PAYLOAD_LURE" })
    }

    @Test
    fun `remote access analyzer flags AnyDesk lure`() {
        val text = "Call support and download AnyDesk to get immediate refund"
        val findings = RemoteAccessAnalyzer.analyzeRemoteAccessLures(text)

        assertTrue(findings.isNotEmpty())
        assertEquals("REMOTE_ACCESS_APP_SOLICITATION", findings.first().ruleId)
    }
}
