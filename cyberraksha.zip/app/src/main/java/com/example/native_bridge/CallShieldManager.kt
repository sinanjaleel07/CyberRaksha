package com.example.native_bridge

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class CallShieldState(
    val isMonitoringActive: Boolean = true,
    val isPhoneCallActive: Boolean = false,
    val isSimulatedCall: Boolean = false,
    val inCallOtpAlertTriggered: Boolean = false,
    val lastAlertMessage: String? = null,
    val permissionGranted: Boolean = false,
    val osLimitationNotice: String = "On Android 10+, background call tracking requires telephony permissions or notification listener. Safety Simulation Mode provides 100% testability without risking device privacy."
)

class CallShieldManager(
    private val context: Context,
    private val ttsManager: TtsAlertManager
) {

    private val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager

    private val _state = MutableStateFlow(CallShieldState())
    val state: StateFlow<CallShieldState> = _state.asStateFlow()

    private var telephonyCallback: Any? = null

    init {
        checkPermissionAndRegisterListener()
    }

    fun checkPermissionAndRegisterListener() {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED

        _state.value = _state.value.copy(permissionGranted = hasPermission)

        if (hasPermission && telephonyManager != null) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val callback = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                        override fun onCallStateChanged(state: Int) {
                            handleCallStateChange(state)
                        }
                    }
                    telephonyCallback = callback
                    telephonyManager.registerTelephonyCallback(context.mainExecutor, callback)
                } else {
                    @Suppress("DEPRECATION")
                    val listener = object : PhoneStateListener() {
                        @Deprecated("Deprecated in Java")
                        override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                            handleCallStateChange(state)
                        }
                    }
                    @Suppress("DEPRECATION")
                    telephonyManager.listen(listener, PhoneStateListener.LISTEN_CALL_STATE)
                }
            } catch (e: Exception) {
                // Graceful fallback
            }
        }
    }

    private fun handleCallStateChange(state: Int) {
        val isOffHook = state == TelephonyManager.CALL_STATE_OFFHOOK
        _state.value = _state.value.copy(
            isPhoneCallActive = isOffHook,
            isSimulatedCall = false
        )
        if (!isOffHook) {
            // Dismiss in-call alert if call ends
            _state.value = _state.value.copy(inCallOtpAlertTriggered = false)
        }
    }

    // Safety Simulation Mode Functions
    fun startSimulatedCall() {
        _state.value = _state.value.copy(
            isPhoneCallActive = true,
            isSimulatedCall = true,
            inCallOtpAlertTriggered = false,
            lastAlertMessage = null
        )
    }

    fun endSimulatedCall() {
        _state.value = _state.value.copy(
            isPhoneCallActive = false,
            isSimulatedCall = false,
            inCallOtpAlertTriggered = false,
            lastAlertMessage = null
        )
    }

    fun triggerSimulatedOtpArrival(useMalayalamTts: Boolean = true) {
        val isCallActive = _state.value.isPhoneCallActive
        if (isCallActive) {
            // Trigger emergency in-call OTP alert
            _state.value = _state.value.copy(
                inCallOtpAlertTriggered = true,
                lastAlertMessage = "CRITICAL ALERT: OTP SMS received while ongoing call is connected! Never share this OTP with the caller."
            )
            // Play voice alert!
            ttsManager.speakAlert(useMalayalam = useMalayalamTts)
        } else {
            // OTP arrived without call -> not an in-call emergency, but standard alert
            _state.value = _state.value.copy(
                lastAlertMessage = "Standard OTP received (No active call detected - normal authentication)."
            )
        }
    }

    fun dismissAlert() {
        _state.value = _state.value.copy(inCallOtpAlertTriggered = false)
        ttsManager.stop()
    }
}
