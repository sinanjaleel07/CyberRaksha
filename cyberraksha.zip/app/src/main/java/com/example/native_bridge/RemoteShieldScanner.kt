package com.example.native_bridge

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.pm.PackageManager
import android.view.accessibility.AccessibilityManager
import com.example.data.model.RemoteAppThreat
import com.example.data.model.ThreatSeverity

class RemoteShieldScanner(private val context: Context) {

    private val monitoredPackages = listOf(
        RemoteAppThreat(
            packageName = "com.anydesk.anydeskandroid",
            appName = "AnyDesk Remote Control",
            riskDescription = "Provides external users full screen mirroring and unattended remote interaction capability.",
            isInstalled = false,
            severity = ThreatSeverity.CRITICAL,
            misuseTactics = "Scammers pretending to be bank executives, electricity officers, or lottery agents urge victims to install AnyDesk to 'verify refunds' or 'fix electricity billing errors', then steal OTPs directly from the victim's screen."
        ),
        RemoteAppThreat(
            packageName = "com.teamviewer.quicksupport.market",
            appName = "TeamViewer QuickSupport",
            riskDescription = "Allows one-tap screen sharing and remote access from PC/mobile.",
            isInstalled = false,
            severity = ThreatSeverity.CRITICAL,
            misuseTactics = "Victims are guided to read out their 9-digit partner ID, allowing scammers to view bank account screens and two-factor SMS codes in real-time."
        ),
        RemoteAppThreat(
            packageName = "com.teamviewer.teamviewer.market.mobile",
            appName = "TeamViewer Remote Control",
            riskDescription = "Full remote administration client.",
            isInstalled = false,
            severity = ThreatSeverity.HIGH,
            misuseTactics = "Misused in fake customer care scams for desktop and mobile mirroring."
        ),
        RemoteAppThreat(
            packageName = "com.carriez.rustdesk",
            appName = "RustDesk Remote Desktop",
            riskDescription = "Open-source remote desktop client.",
            isInstalled = false,
            severity = ThreatSeverity.HIGH,
            misuseTactics = "Alternative screen sharing tool favored by fraudsters when commercial tools are flagged."
        ),
        RemoteAppThreat(
            packageName = "com.sand.airdroid",
            appName = "AirDroid: Remote access & File",
            riskDescription = "Remote access, notification mirroring, and file transfer tool.",
            isInstalled = false,
            severity = ThreatSeverity.HIGH,
            misuseTactics = "Enables notification forwarding, allowing attackers to intercept incoming SMS OTPs remotely."
        ),
        RemoteAppThreat(
            packageName = "com.koushikdutta.vysor",
            appName = "Vysor - Android control on PC",
            riskDescription = "Mirrors Android device display onto computers.",
            isInstalled = false,
            severity = ThreatSeverity.MEDIUM,
            misuseTactics = "Used for remote screen observation."
        ),
        RemoteAppThreat(
            packageName = "com.splashtop.remote.pad.v2",
            appName = "Splashtop Personal Remote",
            riskDescription = "Remote desktop access tool.",
            isInstalled = false,
            severity = ThreatSeverity.MEDIUM,
            misuseTactics = "Remote desktop viewing."
        ),
        RemoteAppThreat(
            packageName = "com.zoho.assist",
            appName = "Zoho Assist - Customer Support",
            riskDescription = "Unattended access and screen sharing client.",
            isInstalled = false,
            severity = ThreatSeverity.MEDIUM,
            misuseTactics = "Used in enterprise impersonation scams."
        )
    )

    fun scanInstalledRemoteApps(): List<RemoteAppThreat> {
        val packageManager = context.packageManager
        return monitoredPackages.map { app ->
            val isInstalled = try {
                packageManager.getPackageInfo(app.packageName, 0)
                true
            } catch (e: PackageManager.NameNotFoundException) {
                false
            }
            app.copy(isInstalled = isInstalled)
        }
    }

    fun getEnabledAccessibilityServices(): List<String> {
        val accessibilityManager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
            ?: return emptyList()
        val enabledServices = accessibilityManager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        return enabledServices.map { service ->
            val serviceName = service.resolveInfo.serviceInfo.name
            val packageName = service.resolveInfo.serviceInfo.packageName
            "$packageName ($serviceName)"
        }
    }
}
