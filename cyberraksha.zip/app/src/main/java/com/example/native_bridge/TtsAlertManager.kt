package com.example.native_bridge

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

class TtsAlertManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    companion object {
        const val MALAYALAM_ALERT_TEXT = "ശ്രദ്ധിക്കുക! നിങ്ങൾ ഫോൺ കോളിൽ ആയിരിക്കുമ്പോൾ OTP ലഭിച്ചിരിക്കുന്നു. ഇത് തട്ടിപ്പിന്റെ സൂചനയായിരിക്കാം."
        const val ENGLISH_ALERT_TEXT = "Warning! You have received an OTP while you are on a phone call. This could be a scam."
    }

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e("TtsAlertManager", "TTS initialization failed: ${e.message}")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
        } else {
            Log.e("TtsAlertManager", "TTS onInit failed with status $status")
        }
    }

    fun speakAlert(useMalayalam: Boolean = true, onComplete: (() -> Unit)? = null) {
        if (!isInitialized || tts == null) {
            Log.w("TtsAlertManager", "TTS not ready yet")
            return
        }

        try {
            if (useMalayalam) {
                // Try Malayalam Locale (ml-IN)
                val malayalamLocale = Locale("ml", "IN")
                val result = tts?.setLanguage(malayalamLocale)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    // Fallback to Indian English or Default if Malayalam voice pack is not pre-installed on device
                    val indiaEnglish = Locale("en", "IN")
                    tts?.setLanguage(indiaEnglish)
                    tts?.speak(MALAYALAM_ALERT_TEXT, TextToSpeech.QUEUE_FLUSH, null, "CYBER_RAKSHA_ALERT")
                } else {
                    tts?.speak(MALAYALAM_ALERT_TEXT, TextToSpeech.QUEUE_FLUSH, null, "CYBER_RAKSHA_ALERT")
                }
            } else {
                val locale = Locale.US
                tts?.setLanguage(locale)
                tts?.speak(ENGLISH_ALERT_TEXT, TextToSpeech.QUEUE_FLUSH, null, "CYBER_RAKSHA_ALERT")
            }
        } catch (e: Exception) {
            Log.e("TtsAlertManager", "Error speaking alert: ${e.message}")
        }
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
