package com.example.service

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import androidx.core.app.NotificationManagerCompat
import com.example.engine.HeuristicEngine
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

data class InterceptedNotification(
    val packageName: String,
    val appLabel: String,
    val title: String,
    val text: String,
    val timestamp: Long,
    val isOtpCandidate: Boolean,
    val riskScore: Int
)

class CyberNotificationListenerService : NotificationListenerService() {

    companion object {
        private const val TAG = "CyberNotifService"

        private val _notificationEvents = MutableSharedFlow<InterceptedNotification>(replay = 5)
        val notificationEvents: SharedFlow<InterceptedNotification> = _notificationEvents.asSharedFlow()

        fun isPermissionGranted(context: Context): Boolean {
            val enabledListeners = NotificationManagerCompat.getEnabledListenerPackages(context)
            return enabledListeners.contains(context.packageName)
        }

        fun getSettingsIntent(context: Context): Intent {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS).apply {
                    putExtra(
                        Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
                        ComponentName(context, CyberNotificationListenerService::class.java).flattenToString()
                    )
                }
            } else {
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        val packageName = sbn.packageName ?: return

        // Filter for communications and banking apps to avoid unnecessary battery/processing
        if (!isMonitoredPackage(packageName)) {
            return
        }

        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        val combinedContent = "$title $text".trim()
        if (combinedContent.isEmpty()) return

        // Check on-device heuristics
        val analysis = HeuristicEngine.analyze(combinedContent)
        val isOtp = combinedContent.contains("otp", ignoreCase = true) ||
                combinedContent.contains("verification code", ignoreCase = true) ||
                combinedContent.contains("one time password", ignoreCase = true)

        val appLabel = getAppNameFromPackage(packageName)
        val event = InterceptedNotification(
            packageName = packageName,
            appLabel = appLabel,
            title = title,
            text = text,
            timestamp = System.currentTimeMillis(),
            isOtpCandidate = isOtp,
            riskScore = analysis.riskScore
        )

        _notificationEvents.tryEmit(event)
        Log.d(TAG, "Analyzed notification from $appLabel, risk: ${analysis.riskScore}")
    }

    private fun isMonitoredPackage(pkg: String): Boolean {
        return pkg.contains("messaging") ||
                pkg.contains("mms") ||
                pkg.contains("sms") ||
                pkg == "com.whatsapp" ||
                pkg == "org.telegram.messenger" ||
                pkg == "com.truecaller" ||
                pkg.contains("bank") ||
                pkg.contains("paytm") ||
                pkg.contains("phonepe") ||
                pkg.contains("upi")
    }

    private fun getAppNameFromPackage(pkg: String): String {
        return try {
            val appInfo = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            pkg
        }
    }
}
