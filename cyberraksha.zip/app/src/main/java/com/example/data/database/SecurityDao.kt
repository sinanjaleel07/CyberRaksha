package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SecurityDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScanResult(scan: ScanResultEntity): Long

    @Query("SELECT * FROM scan_history ORDER BY timestamp DESC")
    fun getAllScans(): Flow<List<ScanResultEntity>>

    @Query("SELECT * FROM scan_history WHERE riskScore >= 40 ORDER BY timestamp DESC")
    fun getThreatScans(): Flow<List<ScanResultEntity>>

    @Query("SELECT COUNT(*) FROM scan_history")
    fun getTotalScansCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM scan_history WHERE riskScore >= 40")
    fun getThreatsDetectedCount(): Flow<Int>

    @Query("DELETE FROM scan_history")
    suspend fun clearHistory()

    @Query("DELETE FROM scan_history WHERE id = :id")
    suspend fun deleteScanById(id: Long)
}
