package com.example.data.model

enum class ThreatSeverity(val weight: Int) {
    INFO(0),
    LOW(15),
    MEDIUM(30),
    HIGH(50),
    CRITICAL(80)
}

enum class ThreatCategory {
    IP_HOSTED_URL,
    SPOOFED_DOMAIN,
    RISKY_TLD,
    MALFORMED_URL,
    UNENCRYPTED_HTTP,
    URGENCY_SCAM,
    OTP_PIN_THEFT,
    FINANCIAL_PHISHING,
    REMOTE_ACCESS_LURE,
    SUSPICIOUS_PAYLOAD
}

enum class OverallRiskLevel(val minScore: Int, val label: String) {
    SAFE(0, "SAFE"),
    LOW(20, "LOW RISK"),
    MEDIUM(40, "SUSPICIOUS"),
    HIGH(70, "HIGH RISK"),
    CRITICAL(90, "CRITICAL THREAT")
}

data class ThreatFinding(
    val ruleId: String,
    val category: ThreatCategory,
    val severity: ThreatSeverity,
    val title: String,
    val matchedContent: String,
    val explanation: String,
    val recommendedAction: String,
    val scoreContribution: Int
)

data class ScanAnalysisResult(
    val id: Long = 0,
    val rawInput: String,
    val inputType: String, // "URL", "SMS", "WHATSAPP", "TELEGRAM", "TEXT"
    val riskScore: Int, // 0 - 100
    val riskLevel: OverallRiskLevel,
    val findings: List<ThreatFinding>,
    val detectedUrls: List<String>,
    val timestamp: Long = System.currentTimeMillis(),
    val summary: String
)
