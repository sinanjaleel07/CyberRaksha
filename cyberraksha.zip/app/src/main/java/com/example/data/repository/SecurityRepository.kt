package com.example.data.repository

import com.example.data.database.ScanResultEntity
import com.example.data.database.SecurityDao
import com.example.data.model.ScanAnalysisResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class SecurityRepository(private val dao: SecurityDao) {

    val allScans: Flow<List<ScanResultEntity>> = dao.getAllScans()
    val threatScans: Flow<List<ScanResultEntity>> = dao.getThreatScans()
    val totalScansCount: Flow<Int> = dao.getTotalScansCount()
    val threatsDetectedCount: Flow<Int> = dao.getThreatsDetectedCount()

    suspend fun saveScan(result: ScanAnalysisResult): Long {
        val findingsSummary = result.findings.joinToString(separator = "; ") { it.title }
        val urlsJoined = result.detectedUrls.joinToString(",")
        val entity = ScanResultEntity(
            rawInput = result.rawInput,
            inputType = result.inputType,
            riskScore = result.riskScore,
            riskLevel = result.riskLevel.name,
            findingsSummary = findingsSummary,
            findingsCount = result.findings.size,
            detectedUrls = urlsJoined,
            timestamp = result.timestamp
        )
        return dao.insertScanResult(entity)
    }

    suspend fun clearHistory() {
        dao.clearHistory()
    }

    suspend fun seedInitialDataIfEmpty() {
        val count = dao.getTotalScansCount().first()
        if (count == 0) {
            // Seed realistic past sample scans so dashboard is informative out of the box
            dao.insertScanResult(
                ScanResultEntity(
                    rawInput = "Dear Customer, Your electricity will be disconnected tonight at 9:30 PM due to unpaid bill. Immediately contact power officer on 9876543210 or update bill at http://192.168.1.45/ebill-pay",
                    inputType = "SMS",
                    riskScore = 95,
                    riskLevel = "CRITICAL",
                    findingsSummary = "IP-Hosted Link; Urgent Service Disconnection Threat; Unregistered Helpline",
                    findingsCount = 3,
                    detectedUrls = "http://192.168.1.45/ebill-pay",
                    timestamp = System.currentTimeMillis() - 3600000 * 4
                )
            )
            dao.insertScanResult(
                ScanResultEntity(
                    rawInput = "SBI ALERT: Your YONO account has been blocked due to missing PAN verification. Please update KYC immediately by downloading SBI-Security.apk from http://sbi-kyc-update.xyz/login",
                    inputType = "WHATSAPP",
                    riskScore = 98,
                    riskLevel = "CRITICAL",
                    findingsSummary = "Spoofed Banking Domain; Risky .xyz TLD; Dangerous .APK Download; Account Block Scam",
                    findingsCount = 4,
                    detectedUrls = "http://sbi-kyc-update.xyz/login",
                    timestamp = System.currentTimeMillis() - 3600000 * 18
                )
            )
            dao.insertScanResult(
                ScanResultEntity(
                    rawInput = "Your ICICI Bank A/c XX1029 is debited for INR 450.00 on 24-Sep-26 by UPI. Avl Bal: INR 18,420.50. If not done by you, SMS BLOCK to 9215676766.",
                    inputType = "SMS",
                    riskScore = 0,
                    riskLevel = "SAFE",
                    findingsSummary = "Standard transaction advisory; No malicious links",
                    findingsCount = 0,
                    detectedUrls = "",
                    timestamp = System.currentTimeMillis() - 3600000 * 30
                )
            )
        }
    }
}
