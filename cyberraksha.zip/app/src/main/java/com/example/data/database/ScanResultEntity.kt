package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scan_history")
data class ScanResultEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val rawInput: String,
    val inputType: String,
    val riskScore: Int,
    val riskLevel: String,
    val findingsSummary: String,
    val findingsCount: Int,
    val detectedUrls: String, // comma-separated or JSON
    val timestamp: Long = System.currentTimeMillis()
)
