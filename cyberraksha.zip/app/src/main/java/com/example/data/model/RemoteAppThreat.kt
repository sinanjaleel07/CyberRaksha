package com.example.data.model

data class RemoteAppThreat(
    val packageName: String,
    val appName: String,
    val riskDescription: String,
    val isInstalled: Boolean,
    val severity: ThreatSeverity = ThreatSeverity.HIGH,
    val misuseTactics: String
)
