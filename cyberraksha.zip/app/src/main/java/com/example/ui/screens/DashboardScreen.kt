package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.ScanResultEntity
import com.example.data.model.OverallRiskLevel
import com.example.ui.components.ProtectionStatusBanner
import com.example.ui.components.RiskScoreGauge
import com.example.ui.localization.Strings
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberSky
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceCardBorder
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberTextTertiary
import com.example.ui.theme.ThreatCritical
import com.example.ui.theme.ThreatMedium
import com.example.ui.theme.ThreatSafe

@Composable
fun DashboardScreen(
    strings: Strings,
    overallScore: Int,
    threatsCount: Int,
    totalScans: Int,
    recentScans: List<ScanResultEntity>,
    isCallActive: Boolean,
    isNotificationShieldGranted: Boolean,
    onNavigateToScanner: () -> Unit,
    onNavigateToCallShield: () -> Unit,
    onNavigateToRemoteShield: () -> Unit,
    onNavigateToEmergency: () -> Unit,
    onNavigateToHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val overallRiskLevel = when {
        overallScore >= 80 -> OverallRiskLevel.SAFE
        overallScore >= 50 -> OverallRiskLevel.LOW
        overallScore >= 30 -> OverallRiskLevel.MEDIUM
        else -> OverallRiskLevel.HIGH
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            // Protection Banner
            ProtectionStatusBanner(
                riskLevel = overallRiskLevel,
                title = if (overallRiskLevel == OverallRiskLevel.SAFE) strings.systemStatusProtected else strings.systemStatusWarning,
                subtitle = "Active on-device heuristic scanning protecting SMS, links, calls & remote apps."
            )
        }

        // Emergency 1930 Quick Action Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onNavigateToEmergency() }
                    .testTag("emergency_banner_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceElevated),
                border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(ThreatCritical.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Emergency,
                            contentDescription = null,
                            tint = ThreatCritical,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "India Cybercrime Helpline: 1930",
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "One-tap emergency call & Golden Hour reporting guide",
                            color = CyberTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Overall Score Gauge
        item {
            RiskScoreGauge(
                score = overallScore,
                riskLevel = overallRiskLevel
            )
        }

        // Stats Counters
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = strings.threatsBlocked,
                    value = "$threatsCount",
                    valueColor = if (threatsCount > 0) ThreatMedium else ThreatSafe,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = strings.scansPerformed,
                    value = "$totalScans",
                    valueColor = CyberCyan,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = strings.activeShields,
                    value = "4 / 4",
                    valueColor = CyberSky,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Shield Modules Grid
        item {
            Text(
                text = "DEFENSE SHIELDS",
                color = CyberCyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        item {
            ShieldCardItem(
                title = strings.tabScanner,
                description = "Scan suspicious SMS, WhatsApp, Telegram text & URLs",
                icon = Icons.Default.QrCodeScanner,
                statusText = "READY",
                statusColor = ThreatSafe,
                onClick = onNavigateToScanner,
                tag = "nav_scanner_item"
            )
        }

        item {
            ShieldCardItem(
                title = strings.tabCallShield,
                description = if (isCallActive) "CALL IN PROGRESS - OTP Guard Active" else "Guards against OTP theft during voice calls",
                icon = Icons.Default.PhoneInTalk,
                statusText = if (isCallActive) "CALL ACTIVE" else "MONITORING",
                statusColor = if (isCallActive) ThreatMedium else ThreatSafe,
                onClick = onNavigateToCallShield,
                tag = "nav_call_shield_item"
            )
        }

        item {
            ShieldCardItem(
                title = strings.tabRemoteShield,
                description = "Scans for AnyDesk, TeamViewer & unauthorized screen share apps",
                icon = Icons.Default.Shield,
                statusText = "ENABLED",
                statusColor = ThreatSafe,
                onClick = onNavigateToRemoteShield,
                tag = "nav_remote_shield_item"
            )
        }

        item {
            ShieldCardItem(
                title = "Notification Shield",
                description = if (isNotificationShieldGranted) "Notification preview scanning granted" else "Requires user permission to inspect notification previews",
                icon = Icons.Default.NotificationsActive,
                statusText = if (isNotificationShieldGranted) "ACTIVE" else "ACTION REQUIRED",
                statusColor = if (isNotificationShieldGranted) ThreatSafe else ThreatMedium,
                onClick = onNavigateToScanner,
                tag = "nav_notif_shield_item"
            )
        }

        // Recent Security Events
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "RECENT SECURITY ACTIVITY",
                    color = CyberCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "View All",
                    color = CyberSky,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clickable { onNavigateToHistory() }
                        .padding(4.dp)
                )
            }
        }

        if (recentScans.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard)
                ) {
                    Text(
                        text = "No recent scans. Use the scanner to evaluate suspicious messages.",
                        color = CyberTextSecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(recentScans.take(3)) { scan ->
                RecentScanCard(scan = scan, onClick = onNavigateToHistory)
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard),
        border = BorderStroke(1.dp, CyberSurfaceCardBorder)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                color = valueColor,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                color = CyberTextTertiary,
                fontSize = 10.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ShieldCardItem(
    title: String,
    description: String,
    icon: ImageVector,
    statusText: String,
    statusColor: Color,
    onClick: () -> Unit,
    tag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .testTag(tag),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard),
        border = BorderStroke(1.dp, CyberSurfaceCardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberSurfaceElevated),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = CyberCyan,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = CyberTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    color = CyberTextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
                color = statusColor.copy(alpha = 0.15f),
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(1.dp, statusColor.copy(alpha = 0.4f))
            ) {
                Text(
                    text = statusText,
                    color = statusColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
    }
}

@Composable
private fun RecentScanCard(
    scan: ScanResultEntity,
    onClick: () -> Unit
) {
    val riskColor = if (scan.riskScore >= 70) ThreatCritical else if (scan.riskScore >= 40) ThreatMedium else ThreatSafe

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard),
        border = BorderStroke(1.dp, CyberSurfaceCardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(riskColor)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = scan.findingsSummary.ifBlank { "Analyzed ${scan.inputType} message" },
                    color = CyberTextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )
                Text(
                    text = scan.rawInput,
                    color = CyberTextTertiary,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "${scan.riskScore}%",
                color = riskColor,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
