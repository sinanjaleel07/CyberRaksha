package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// CyberRaksha Dark Palette
val CyberBackground = Color(0xFF070B14)
val CyberSurface = Color(0xFF0D1527)
val CyberSurfaceCard = Color(0xFF111C35)
val CyberSurfaceCardBorder = Color(0xFF1E325A)
val CyberSurfaceElevated = Color(0xFF162544)

// Electric Accents
val CyberCyan = Color(0xFF00F2FE)
val CyberCyanMuted = Color(0xFF00A3AD)
val CyberBlue = Color(0xFF0072FF)
val CyberSky = Color(0xFF38BDF8)
val CyberPurple = Color(0xFF8B5CF6)

// Threat Level Colors
val ThreatSafe = Color(0xFF10B981)
val ThreatSafeBg = Color(0xFF063726)
val ThreatLow = Color(0xFF34D399)
val ThreatLowBg = Color(0xFF0A3B2F)
val ThreatMedium = Color(0xFFF59E0B)
val ThreatMediumBg = Color(0xFF452B05)
val ThreatHigh = Color(0xFFF97316)
val ThreatHighBg = Color(0xFF431C04)
val ThreatCritical = Color(0xFFEF4444)
val ThreatCriticalBg = Color(0xFF4C0F17)
val ThreatNeonRed = Color(0xFFFF2A55)

// Text and Icon Colors
val CyberTextPrimary = Color(0xFFF1F5F9)
val CyberTextSecondary = Color(0xFF94A3B8)
val CyberTextTertiary = Color(0xFF64748B)
val CyberDivider = Color(0xFF1E293B)
