package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val icon: ImageVector) {
    object Dashboard : Screen("dashboard", Icons.Default.Dashboard)
    object Scanner : Screen("scanner", Icons.Default.QrCodeScanner)
    object CallShield : Screen("call_shield", Icons.Default.PhoneInTalk)
    object RemoteShield : Screen("remote_shield", Icons.Default.Shield)
    object Emergency : Screen("emergency", Icons.Default.Emergency)
    object History : Screen("history", Icons.Default.History)
    object Privacy : Screen("privacy", Icons.Default.Policy)
    object Architecture : Screen("architecture", Icons.Default.Terminal)
    object Settings : Screen("settings", Icons.Default.Settings)
}
