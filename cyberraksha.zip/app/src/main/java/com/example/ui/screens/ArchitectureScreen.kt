package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DataObject
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberSky
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceCardBorder
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberTextTertiary
import com.example.ui.theme.ThreatSafe

@Composable
fun ArchitectureScreen(
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "CyberRaksha System Architecture",
                color = CyberTextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Three-tier decoupled architecture: UI Layer, On-Device Heuristic Engine, and Native Android Service Bridge.",
                color = CyberTextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }

        // Layer 1: UI Presentation
        item {
            LayerCard(
                layerNumber = "LAYER 1",
                title = "UI Presentation & Reactive State",
                icon = Icons.Default.PhoneAndroid,
                accentColor = CyberCyan,
                components = listOf(
                    "Jetpack Compose Material 3 dark cybernetic visual system",
                    "English & Malayalam (മലയാളം) dynamic bilingual localization dictionary",
                    "StateFlow & MVVM reactive unidirectional data stream",
                    "Real-time visual threat meters, interactive simulation sandbox"
                )
            )
        }

        // Layer 2: On-Device Heuristic Engine
        item {
            LayerCard(
                layerNumber = "LAYER 2",
                title = "On-Device Heuristic Engine",
                icon = Icons.Default.Memory,
                accentColor = CyberSky,
                components = listOf(
                    "UrlAnalyzer: IP-based link detection, spoofed banking domains, risky TLDs (.top, .xyz, .apk), punycode/homoglyphs, shorteners, unencrypted HTTP",
                    "TextPatternAnalyzer: Urgency/scare tactics, power cut threats, OTP & UPI PIN theft patterns (English & Malayalam)",
                    "RemoteAccessAnalyzer: Detects lures for AnyDesk, TeamViewer, QuickSupport, RustDesk, screen mirroring",
                    "HeuristicEngine: Deterministic composite scoring (0-100) with explainable rule attribution; 100% offline & local"
                )
            )
        }

        // Layer 3: Native Android System & Service Bridge
        item {
            LayerCard(
                layerNumber = "LAYER 3",
                title = "Android Native Services & Room DB",
                icon = Icons.Default.DataObject,
                accentColor = CyberBlue,
                components = listOf(
                    "CyberNotificationListenerService: Notification preview extraction with explicit user consent",
                    "CallShieldManager: TelephonyManager listener & Interactive Safety Simulation Mode",
                    "RemoteShieldScanner: PackageManager queries for RAT tools & Accessibility services audit",
                    "TtsAlertManager: Android TextToSpeech synthesis for Malayalam & English emergency warnings",
                    "CyberRakshaDatabase: Local SQLite Room persistence for audit logs & threat telemetry"
                )
            )
        }

        // Release APK & Production Build Workflow
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard),
                border = BorderStroke(1.dp, CyberSurfaceCardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Terminal,
                            contentDescription = null,
                            tint = ThreatSafe,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SIGNED-RELEASE-READY APK WORKFLOW",
                            color = ThreatSafe,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "The codebase is configured for automated reproducible Gradle release compilation without external dependencies:",
                        color = CyberTextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        color = CyberSurface,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "# Build signed debug or release APK\n./gradlew :app:assembleRelease\n./gradlew :app:assembleDebug",
                                color = CyberCyan,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• R8 / Proguard optimizations configured in proguard-rules.pro\n• Zero third-party web tracking SDKs\n• Target SDK: 36 (Android 16 compatible) with minSdk 24 (Android 7.0+)",
                        color = CyberTextTertiary,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun LayerCard(
    layerNumber: String,
    title: String,
    icon: ImageVector,
    accentColor: androidx.compose.ui.graphics.Color,
    components: List<String>
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard),
        border = BorderStroke(1.dp, CyberSurfaceCardBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = accentColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, accentColor.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = layerNumber,
                        color = accentColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(CyberSurfaceElevated),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                color = CyberTextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )

            Spacer(modifier = Modifier.height(10.dp))
            components.forEach { comp ->
                Row(
                    modifier = Modifier.padding(vertical = 3.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = "•",
                        color = accentColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = comp,
                        color = CyberTextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}
