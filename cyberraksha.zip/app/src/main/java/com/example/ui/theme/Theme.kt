package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val CyberColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = CyberBackground,
    primaryContainer = CyberSurfaceCard,
    onPrimaryContainer = CyberCyan,
    secondary = CyberBlue,
    onSecondary = CyberTextPrimary,
    secondaryContainer = CyberSurfaceElevated,
    onSecondaryContainer = CyberSky,
    tertiary = CyberSky,
    onTertiary = CyberBackground,
    background = CyberBackground,
    onBackground = CyberTextPrimary,
    surface = CyberSurface,
    onSurface = CyberTextPrimary,
    surfaceVariant = CyberSurfaceCard,
    onSurfaceVariant = CyberTextSecondary,
    outline = CyberSurfaceCardBorder,
    outlineVariant = CyberDivider,
    error = ThreatCritical,
    onError = CyberTextPrimary,
    errorContainer = ThreatCriticalBg,
    onErrorContainer = ThreatNeonRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // CyberRaksha is intentionally dark cyber-themed
    dynamicColor: Boolean = false, // Keep consistent cyber branding
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = CyberBackground.toArgb()
                window.navigationBarColor = CyberBackground.toArgb()
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = false
                controller.isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = CyberColorScheme,
        typography = Typography,
        content = content
    )
}
