package com.example

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.CyberRakshaDatabase
import com.example.data.database.ScanResultEntity
import com.example.data.repository.SecurityRepository
import com.example.native_bridge.CallShieldManager
import com.example.native_bridge.RemoteShieldScanner
import com.example.native_bridge.TtsAlertManager
import com.example.service.CyberNotificationListenerService
import com.example.ui.components.CyberAppTopBar
import com.example.ui.localization.AppLanguage
import com.example.ui.localization.EnglishStrings
import com.example.ui.localization.MalayalamStrings
import com.example.ui.navigation.Screen
import com.example.ui.screens.ArchitectureScreen
import com.example.ui.screens.CallShieldScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.Emergency1930Screen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.PrivacyCenterScreen
import com.example.ui.screens.RemoteShieldScreen
import com.example.ui.screens.ScannerScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberSky
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberTextTertiary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ThreatCritical
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var ttsManager: TtsAlertManager
    private lateinit var callShieldManager: CallShieldManager
    private lateinit var remoteShieldScanner: RemoteShieldScanner
    private lateinit var repository: SecurityRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val db = CyberRakshaDatabase.getDatabase(this)
        repository = SecurityRepository(db.securityDao())
        ttsManager = TtsAlertManager(this)
        callShieldManager = CallShieldManager(this, ttsManager)
        remoteShieldScanner = RemoteShieldScanner(this)

        setContent {
            MyApplicationTheme {
                CyberRakshaApp(
                    repository = repository,
                    callShieldManager = callShieldManager,
                    ttsManager = ttsManager,
                    remoteShieldScanner = remoteShieldScanner
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ttsManager.shutdown()
    }
}

@Composable
fun CyberRakshaApp(
    repository: SecurityRepository,
    callShieldManager: CallShieldManager,
    ttsManager: TtsAlertManager,
    remoteShieldScanner: RemoteShieldScanner
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Preferences & Localization State
    var currentLanguage by remember { mutableStateOf(AppLanguage.ENGLISH) }
    var useMalayalamTts by remember { mutableStateOf(true) }
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Dashboard) }
    var showMoreMenu by remember { mutableStateOf(false) }

    val strings = if (currentLanguage == AppLanguage.ENGLISH) EnglishStrings else MalayalamStrings

    // Room Database State
    val allScans by repository.allScans.collectAsState(initial = emptyList())
    val totalScans by repository.totalScansCount.collectAsState(initial = 0)
    val threatsCount by repository.threatsDetectedCount.collectAsState(initial = 0)

    // Telephony / Call Shield State
    val callState by callShieldManager.state.collectAsState()

    // Notification Service Granted Status
    val isNotificationGranted = CyberNotificationListenerService.isPermissionGranted(context)

    // Calculate dynamic security score: 100 base, minus penalty for recent unhandled threats
    val overallScore = remember(allScans, threatsCount) {
        val recentThreats = allScans.take(10).count { it.riskScore >= 70 }
        val penalty = recentThreats * 15
        (100 - penalty).coerceIn(20, 100)
    }

    // Seed realistic samples if initial DB is empty
    LaunchedEffect(Unit) {
        repository.seedInitialDataIfEmpty()
    }

    // Listen to incoming notifications and trigger in-call OTP detection
    LaunchedEffect(Unit) {
        CyberNotificationListenerService.notificationEvents.collectLatest { notif ->
            if (notif.isOtpCandidate && callState.isPhoneCallActive) {
                callShieldManager.triggerSimulatedOtpArrival(useMalayalamTts = useMalayalamTts)
            }
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        topBar = {
            CyberAppTopBar(
                appName = strings.appName,
                currentLanguageName = currentLanguage.nativeName,
                onToggleLanguage = {
                    currentLanguage = if (currentLanguage == AppLanguage.ENGLISH) AppLanguage.MALAYALAM else AppLanguage.ENGLISH
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = CyberSurface,
                contentColor = CyberTextPrimary,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                NavigationBarItem(
                    selected = currentScreen == Screen.Dashboard,
                    onClick = { currentScreen = Screen.Dashboard },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = strings.tabDashboard) },
                    label = { Text(strings.tabDashboard, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberBackground,
                        indicatorColor = CyberCyan,
                        selectedTextColor = CyberCyan,
                        unselectedIconColor = CyberTextTertiary,
                        unselectedTextColor = CyberTextTertiary
                    ),
                    modifier = Modifier.testTag("nav_item_dashboard")
                )
                NavigationBarItem(
                    selected = currentScreen == Screen.Scanner,
                    onClick = { currentScreen = Screen.Scanner },
                    icon = { Icon(Icons.Default.QrCodeScanner, contentDescription = strings.tabScanner) },
                    label = { Text(strings.tabScanner, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberBackground,
                        indicatorColor = CyberCyan,
                        selectedTextColor = CyberCyan,
                        unselectedIconColor = CyberTextTertiary,
                        unselectedTextColor = CyberTextTertiary
                    ),
                    modifier = Modifier.testTag("nav_item_scanner")
                )
                NavigationBarItem(
                    selected = currentScreen == Screen.CallShield,
                    onClick = { currentScreen = Screen.CallShield },
                    icon = { Icon(Icons.Default.PhoneInTalk, contentDescription = strings.tabCallShield) },
                    label = { Text(strings.tabCallShield, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberBackground,
                        indicatorColor = CyberCyan,
                        selectedTextColor = CyberCyan,
                        unselectedIconColor = CyberTextTertiary,
                        unselectedTextColor = CyberTextTertiary
                    ),
                    modifier = Modifier.testTag("nav_item_call_shield")
                )
                NavigationBarItem(
                    selected = currentScreen == Screen.RemoteShield,
                    onClick = { currentScreen = Screen.RemoteShield },
                    icon = { Icon(Icons.Default.Shield, contentDescription = strings.tabRemoteShield) },
                    label = { Text(strings.tabRemoteShield, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberBackground,
                        indicatorColor = CyberCyan,
                        selectedTextColor = CyberCyan,
                        unselectedIconColor = CyberTextTertiary,
                        unselectedTextColor = CyberTextTertiary
                    ),
                    modifier = Modifier.testTag("nav_item_remote_shield")
                )
                NavigationBarItem(
                    selected = currentScreen == Screen.Emergency,
                    onClick = { currentScreen = Screen.Emergency },
                    icon = { Icon(Icons.Default.Emergency, contentDescription = "1930", tint = ThreatCritical) },
                    label = { Text("1930", fontSize = 10.sp, color = ThreatCritical) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberBackground,
                        indicatorColor = ThreatCritical,
                        selectedTextColor = ThreatCritical,
                        unselectedIconColor = ThreatCritical,
                        unselectedTextColor = ThreatCritical
                    ),
                    modifier = Modifier.testTag("nav_item_emergency")
                )
                NavigationBarItem(
                    selected = currentScreen in listOf(Screen.History, Screen.Privacy, Screen.Architecture, Screen.Settings),
                    onClick = { showMoreMenu = true },
                    icon = {
                        Box {
                            Icon(Icons.Default.MoreHoriz, contentDescription = "More")
                            DropdownMenu(
                                expanded = showMoreMenu,
                                onDismissRequest = { showMoreMenu = false },
                                modifier = Modifier.background(CyberSurfaceCard)
                            ) {
                                DropdownMenuItem(
                                    text = { Text(strings.tabHistory, color = CyberTextPrimary) },
                                    leadingIcon = { Icon(Icons.Default.History, contentDescription = null, tint = CyberSky) },
                                    onClick = {
                                        currentScreen = Screen.History
                                        showMoreMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(strings.tabPrivacy, color = CyberTextPrimary) },
                                    leadingIcon = { Icon(Icons.Default.Policy, contentDescription = null, tint = CyberCyan) },
                                    onClick = {
                                        currentScreen = Screen.Privacy
                                        showMoreMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(strings.tabArchitecture, color = CyberTextPrimary) },
                                    leadingIcon = { Icon(Icons.Default.Terminal, contentDescription = null, tint = CyberSky) },
                                    onClick = {
                                        currentScreen = Screen.Architecture
                                        showMoreMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(strings.tabSettings, color = CyberTextPrimary) },
                                    leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null, tint = CyberCyan) },
                                    onClick = {
                                        currentScreen = Screen.Settings
                                        showMoreMenu = false
                                    }
                                )
                            }
                        }
                    },
                    label = { Text("More", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberBackground,
                        indicatorColor = CyberCyan,
                        selectedTextColor = CyberCyan,
                        unselectedIconColor = CyberTextTertiary,
                        unselectedTextColor = CyberTextTertiary
                    ),
                    modifier = Modifier.testTag("nav_item_more")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(CyberBackground)
        ) {
            Crossfade(targetState = currentScreen, label = "screenTransition") { screen ->
                when (screen) {
                    Screen.Dashboard -> DashboardScreen(
                        strings = strings,
                        overallScore = overallScore,
                        threatsCount = threatsCount,
                        totalScans = totalScans,
                        recentScans = allScans,
                        isCallActive = callState.isPhoneCallActive,
                        isNotificationShieldGranted = isNotificationGranted,
                        onNavigateToScanner = { currentScreen = Screen.Scanner },
                        onNavigateToCallShield = { currentScreen = Screen.CallShield },
                        onNavigateToRemoteShield = { currentScreen = Screen.RemoteShield },
                        onNavigateToEmergency = { currentScreen = Screen.Emergency },
                        onNavigateToHistory = { currentScreen = Screen.History }
                    )
                    Screen.Scanner -> ScannerScreen(
                        strings = strings,
                        onSaveScan = { result ->
                            coroutineScope.launch {
                                repository.saveScan(result)
                            }
                        }
                    )
                    Screen.CallShield -> CallShieldScreen(
                        strings = strings,
                        callShieldManager = callShieldManager,
                        ttsManager = ttsManager,
                        useMalayalamTts = useMalayalamTts
                    )
                    Screen.RemoteShield -> RemoteShieldScreen(
                        strings = strings,
                        scanner = remoteShieldScanner
                    )
                    Screen.Emergency -> Emergency1930Screen(
                        strings = strings
                    )
                    Screen.History -> HistoryScreen(
                        strings = strings,
                        scans = allScans,
                        onClearHistory = {
                            coroutineScope.launch {
                                repository.clearHistory()
                            }
                        }
                    )
                    Screen.Privacy -> PrivacyCenterScreen(
                        strings = strings
                    )
                    Screen.Architecture -> ArchitectureScreen()
                    Screen.Settings -> SettingsScreen(
                        strings = strings,
                        currentLanguage = currentLanguage,
                        onSelectLanguage = { currentLanguage = it },
                        useMalayalamTts = useMalayalamTts,
                        onToggleTtsLanguage = { useMalayalamTts = it },
                        onClearHistory = {
                            coroutineScope.launch {
                                repository.clearHistory()
                            }
                        }
                    )
                }
            }
        }
    }
}
