package com.example.engine

import com.example.data.model.OverallRiskLevel
import com.example.data.model.ScanAnalysisResult
import com.example.data.model.ThreatFinding
import com.example.data.model.ThreatSeverity
import kotlin.math.min

object HeuristicEngine {

    fun analyze(input: String): ScanAnalysisResult {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) {
            return ScanAnalysisResult(
                rawInput = "",
                inputType = "TEXT",
                riskScore = 0,
                riskLevel = OverallRiskLevel.SAFE,
                findings = emptyList(),
                detectedUrls = emptyList(),
                summary = "Empty input supplied."
            )
        }

        val detectedUrls = UrlAnalyzer.extractUrls(trimmed)
        val inputType = inferInputType(trimmed, detectedUrls)

        val allFindings = mutableListOf<ThreatFinding>()

        // 1. Analyze all extracted URLs
        for (url in detectedUrls) {
            allFindings.addAll(UrlAnalyzer.analyzeUrl(url))
        }

        // 2. Analyze Text Patterns (scams, urgency, financial baits, OTP theft)
        allFindings.addAll(TextPatternAnalyzer.analyzeText(trimmed))

        // 3. Analyze Remote Access Indicators
        allFindings.addAll(RemoteAccessAnalyzer.analyzeRemoteAccessLures(trimmed))

        // Deduplicate findings by ruleId
        val uniqueFindings = allFindings.distinctBy { it.ruleId }

        // Compute Transparent Composite Risk Score
        // Base score = sum of score contributions capped at 100
        // Bonus multipliers if critical combinations exist (e.g. Urgency + IP/Phishing Link or In-call + OTP)
        var calculatedScore = uniqueFindings.sumOf { it.scoreContribution }

        val hasCritical = uniqueFindings.any { it.severity == ThreatSeverity.CRITICAL }
        val hasHigh = uniqueFindings.any { it.severity == ThreatSeverity.HIGH }

        if (hasCritical && hasHigh) {
            calculatedScore += 15
        }

        val finalScore = min(100, calculatedScore)

        val riskLevel = when {
            finalScore >= 90 -> OverallRiskLevel.CRITICAL
            finalScore >= 70 -> OverallRiskLevel.HIGH
            finalScore >= 40 -> OverallRiskLevel.MEDIUM
            finalScore >= 20 -> OverallRiskLevel.LOW
            else -> OverallRiskLevel.SAFE
        }

        val summary = generateSummary(riskLevel, uniqueFindings)

        return ScanAnalysisResult(
            rawInput = trimmed,
            inputType = inputType,
            riskScore = finalScore,
            riskLevel = riskLevel,
            findings = uniqueFindings,
            detectedUrls = detectedUrls,
            timestamp = System.currentTimeMillis(),
            summary = summary
        )
    }

    private fun inferInputType(text: String, urls: List<String>): String {
        val lower = text.lowercase()
        return when {
            urls.isNotEmpty() && text == urls.first() -> "URL"
            lower.contains("whatsapp") || lower.contains("forwarded") -> "WHATSAPP"
            lower.contains("telegram") || lower.contains("t.me") -> "TELEGRAM"
            lower.contains("otp") || lower.contains("a/c") || lower.contains("debited") || lower.contains("credited") -> "SMS"
            urls.isNotEmpty() -> "LINK_MESSAGE"
            else -> "TEXT"
        }
    }

    private fun generateSummary(riskLevel: OverallRiskLevel, findings: List<ThreatFinding>): String {
        return when (riskLevel) {
            OverallRiskLevel.SAFE ->
                "No evident threat signatures detected. Normal caution is advised for any unsolicited communications."
            OverallRiskLevel.LOW ->
                "Low suspicion detected (${findings.size} minor warning). Review details before proceeding."
            OverallRiskLevel.MEDIUM ->
                "Suspicious characteristics found (${findings.size} indicators). Exercise high caution; do not share sensitive data."
            OverallRiskLevel.HIGH ->
                "High-risk message or link detected. Contains multiple deception markers commonly used in cybercrime."
            OverallRiskLevel.CRITICAL ->
                "CRITICAL FRAUD THREAT! This communication exhibits active credentials theft, fake branding, or malicious payload distribution."
        }
    }
}
