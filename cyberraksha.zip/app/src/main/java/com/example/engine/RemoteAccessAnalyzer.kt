package com.example.engine

import com.example.data.model.ThreatCategory
import com.example.data.model.ThreatFinding
import com.example.data.model.ThreatSeverity

object RemoteAccessAnalyzer {

    private val RAT_APP_NAMES = listOf(
        "anydesk", "teamviewer", "quicksupport", "rustdesk",
        "airdroid", "vysor", "splashtop", "ultraviewer", "zoho assist"
    )

    private val SCREEN_SHARE_TERMS = listOf(
        Regex("(?i)\\b(download|install)\\s+.*(anydesk|teamviewer|quicksupport|rustdesk)\\b"),
        Regex("(?i)\\b(share\\s*(your)?\\s*screen|allow\\s*remote\\s*access)\\b"),
        Regex("(?i)\\b(give\\s*(the)?\\s*9[ -]?digit\\s*(code|id))\\b"),
        Regex("(?i)\\b(technical\\s*support\\s*will\\s*connect)\\b"),
        // Malayalam terms
        Regex("ആനിഡെസ്ക്|ടീംവ്യൂവർ|ക്വിക്ക്സപ്പോർട്ട്"),
        Regex("സ്ക്രീൻ\\s*ഷെയർ\\s*(ചെയ്യുക|ചെയ്യണം)")
    )

    fun analyzeRemoteAccessLures(text: String): List<ThreatFinding> {
        val findings = mutableListOf<ThreatFinding>()
        val lower = text.lowercase()

        val mentionedApp = RAT_APP_NAMES.find { lower.contains(it) }
        val matchesScreenAction = SCREEN_SHARE_TERMS.any { it.containsMatchIn(text) }

        if (mentionedApp != null || matchesScreenAction) {
            findings.add(
                ThreatFinding(
                    ruleId = "REMOTE_ACCESS_APP_SOLICITATION",
                    category = ThreatCategory.REMOTE_ACCESS_LURE,
                    severity = ThreatSeverity.CRITICAL,
                    title = "Remote Control / Screen-Sharing App Lure",
                    matchedContent = mentionedApp ?: "Screen share request",
                    explanation = "The message instructs or urges the installation of remote desktop software (${mentionedApp ?: "remote app"}). Fraudsters use these tools to take full visual and remote control of your phone and view two-factor authentication OTPs in real-time.",
                    recommendedAction = "NEVER install remote control applications at the instruction of someone on a phone call or chat. Immediately terminate the call.",
                    scoreContribution = 55
                )
            )
        }

        return findings
    }
}
