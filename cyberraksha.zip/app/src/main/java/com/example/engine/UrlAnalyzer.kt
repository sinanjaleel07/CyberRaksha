package com.example.engine

import com.example.data.model.ThreatCategory
import com.example.data.model.ThreatFinding
import com.example.data.model.ThreatSeverity
import java.net.URI
import java.util.regex.Pattern

object UrlAnalyzer {

    // Regex to match URLs in text
    private val URL_REGEX = Pattern.compile(
        "\\b(https?://[a-zA-Z0-9+&@#/%?=~_|!:,.;\\-]*[a-zA-Z0-9+&@#/%=~_|\\-])",
        Pattern.CASE_INSENSITIVE
    )

    // Regex for bare domains or IP links without protocol
    private val BARE_URL_REGEX = Pattern.compile(
        "\\b((?:[a-zA-Z0-9-]+\\.)+(?:top|xyz|work|click|buzz|link|live|loan|vip|cfd|sbs|com|in|org|net|co)/[a-zA-Z0-9+&@#/%?=~_|!:,.;\\-]*)",
        Pattern.CASE_INSENSITIVE
    )

    // IPv4 Address Pattern
    private val IP_PATTERN = Pattern.compile(
        "^https?://(?:\\d{1,3}\\.){3}\\d{1,3}(?::\\d+)?(?:/.*)?$",
        Pattern.CASE_INSENSITIVE
    )

    // Known Risky TLDs commonly abused for spam & fraud
    private val RISKY_TLDS = setOf(
        "top", "xyz", "work", "click", "buzz", "apk", "link", "live", "loan",
        "cam", "vip", "party", "monster", "cfd", "rest", "sbs", "icu", "tk", "ml", "ga"
    )

    // URL Shorteners that conceal the real destination
    private val URL_SHORTENERS = setOf(
        "bit.ly", "tinyurl.com", "is.gd", "cutt.ly", "rb.gy", "t.co", "ow.ly", "goo.gl", "rebrand.ly"
    )

    // Legitimate Indian Banking & Public Sector Brands frequently spoofed
    private val TARGETED_BRANDS = listOf(
        "sbi", "hdfc", "icici", "pnb", "axis", "bob", "canara", "unionbank",
        "paytm", "phonepe", "gpay", "bhim", "incometax", "indiapost", "epfo",
        "uidai", "aadhaar", "irctc", "bescom", "kseb", "tneb", "mahadiscom"
    )

    fun extractUrls(text: String): List<String> {
        val urls = mutableListOf<String>()
        val matcher = URL_REGEX.matcher(text)
        while (matcher.find()) {
            urls.add(matcher.group())
        }
        if (urls.isEmpty()) {
            val bareMatcher = BARE_URL_REGEX.matcher(text)
            while (bareMatcher.find()) {
                urls.add("http://" + bareMatcher.group())
            }
        }
        return urls.distinct()
    }

    fun analyzeUrl(urlStr: String): List<ThreatFinding> {
        val findings = mutableListOf<ThreatFinding>()
        val lowerUrl = urlStr.lowercase()

        // 1. Check IP-Hosted URL
        if (IP_PATTERN.matcher(urlStr).matches() || lowerUrl.matches(Regex("^https?://(?:\\d{1,3}\\.){3}\\d{1,3}.*"))) {
            findings.add(
                ThreatFinding(
                    ruleId = "URL_IP_BASED",
                    category = ThreatCategory.IP_HOSTED_URL,
                    severity = ThreatSeverity.CRITICAL,
                    title = "Suspicious Direct IP-Based Link",
                    matchedContent = urlStr,
                    explanation = "Legitimate banks and organizations use registered domain names with valid SSL certificates, never bare numeric IP addresses.",
                    recommendedAction = "Do NOT open this link. It bypasses domain reputation and is characteristic of phishing servers.",
                    scoreContribution = 45
                )
            )
        }

        // Try parsing hostname via URI
        val host: String? = try {
            val uri = URI(if (!urlStr.startsWith("http")) "http://$urlStr" else urlStr)
            uri.host?.lowercase()
        } catch (e: Exception) {
            null
        }

        if (host != null) {
            // 2. Risky TLD Detection
            val hostParts = host.split(".")
            val tld = hostParts.lastOrNull()
            if (tld != null && RISKY_TLDS.contains(tld)) {
                findings.add(
                    ThreatFinding(
                        ruleId = "URL_RISKY_TLD",
                        category = ThreatCategory.RISKY_TLD,
                        severity = ThreatSeverity.HIGH,
                        title = "High-Risk Top Level Domain (.$tld)",
                        matchedContent = host,
                        explanation = "The domain extension '.$tld' is statistically associated with disposable phishing campaigns and malware distribution.",
                        recommendedAction = "Inspect domain carefully. Avoid entering any credentials or phone numbers.",
                        scoreContribution = 30
                    )
                )
            }

            // 3. Spoofed Brand Names & Hyphenated Phishing Domains
            for (brand in TARGETED_BRANDS) {
                if (host.contains(brand)) {
                    val isOfficial = isKnownOfficialDomain(host, brand)
                    if (!isOfficial) {
                        findings.add(
                            ThreatFinding(
                                ruleId = "URL_SPOOFED_BRAND_$brand",
                                category = ThreatCategory.SPOOFED_DOMAIN,
                                severity = ThreatSeverity.CRITICAL,
                                title = "Possible Spoofed Brand Domain ($brand)",
                                matchedContent = host,
                                explanation = "The link contains '$brand' in its address but does not match the official verified domain of the organization.",
                                recommendedAction = "Phishing threat detected. Banks never send login links via unofficial domains.",
                                scoreContribution = 50
                            )
                        )
                    }
                }
            }

            // 4. Excessive Subdomains (Domain Masking)
            if (hostParts.size > 4) {
                findings.add(
                    ThreatFinding(
                        ruleId = "URL_EXCESSIVE_SUBDOMAINS",
                        category = ThreatCategory.MALFORMED_URL,
                        severity = ThreatSeverity.MEDIUM,
                        title = "Excessive Subdomain Levels",
                        matchedContent = host,
                        explanation = "The domain has ${hostParts.size} parts. Attackers use deep subdomains to camouflage the actual controlling root domain on mobile screens.",
                        recommendedAction = "Verify the true rightmost domain name before trusting this page.",
                        scoreContribution = 20
                    )
                )
            }

            // 5. URL Shorteners
            if (URL_SHORTENERS.contains(host)) {
                findings.add(
                    ThreatFinding(
                        ruleId = "URL_SHORTENER_DETECTED",
                        category = ThreatCategory.MALFORMED_URL,
                        severity = ThreatSeverity.MEDIUM,
                        title = "Hidden Destination (URL Shortener)",
                        matchedContent = host,
                        explanation = "Shortened links obscure the final website address, preventing users from seeing where they will land.",
                        recommendedAction = "Never click shortened links in SMS from unknown senders without unshortening them.",
                        scoreContribution = 20
                    )
                )
            }

            // 6. Punycode / Homoglyph Detection
            if (host.startsWith("xn--") || host.contains(".xn--")) {
                findings.add(
                    ThreatFinding(
                        ruleId = "URL_PUNYCODE_HOMOGLYPH",
                        category = ThreatCategory.SPOOFED_DOMAIN,
                        severity = ThreatSeverity.CRITICAL,
                        title = "Punycode Homoglyph Deception",
                        matchedContent = host,
                        explanation = "This address uses internationalized characters that look identical to Latin letters but direct to an attacker's server.",
                        recommendedAction = "High-risk spoofing attempt. Do not navigate to this site.",
                        scoreContribution = 45
                    )
                )
            }
        }

        // 7. Unencrypted HTTP Connection
        if (urlStr.startsWith("http://", ignoreCase = true) && !urlStr.startsWith("http://192.168.1.1")) {
            val sensitiveContext = lowerUrl.contains("login") || lowerUrl.contains("bank") ||
                    lowerUrl.contains("kyc") || lowerUrl.contains("pay") || lowerUrl.contains("bill")
            findings.add(
                ThreatFinding(
                    ruleId = "URL_UNENCRYPTED_HTTP",
                    category = ThreatCategory.UNENCRYPTED_HTTP,
                    severity = if (sensitiveContext) ThreatSeverity.HIGH else ThreatSeverity.LOW,
                    title = "Unencrypted HTTP Connection",
                    matchedContent = urlStr,
                    explanation = "This link uses unencrypted HTTP. Any data sent can be intercepted, read, or modified by third parties.",
                    recommendedAction = "Never enter personal details, passwords, or financial cards on unencrypted HTTP pages.",
                    scoreContribution = if (sensitiveContext) 30 else 15
                )
            )
        }

        // 8. Direct APK / Executable Download
        if (lowerUrl.endsWith(".apk") || lowerUrl.contains(".apk?") || lowerUrl.contains(".exe") || lowerUrl.contains("download_app")) {
            findings.add(
                ThreatFinding(
                    ruleId = "URL_DIRECT_APK_PAYLOAD",
                    category = ThreatCategory.SUSPICIOUS_PAYLOAD,
                    severity = ThreatSeverity.CRITICAL,
                    title = "Direct Android Package (.APK) Download",
                    matchedContent = urlStr,
                    explanation = "Direct APK links bypass Google Play Protect screening and often deliver banking trojans or RAT spyware.",
                    recommendedAction = "NEVER install .apk files received via SMS or messaging apps. Only install from Google Play Store.",
                    scoreContribution = 50
                )
            )
        }

        return findings
    }

    private fun isKnownOfficialDomain(host: String, brand: String): Boolean {
        val officialDomains = mapOf(
            "sbi" to setOf("onlinesbi.sbi", "sbi.co.in", "bank.sbi", "statebankofindia.com"),
            "hdfc" to setOf("hdfcbank.com", "hdfc.com"),
            "icici" to setOf("icicibank.com"),
            "pnb" to setOf("pnbindia.in"),
            "axis" to setOf("axisbank.com"),
            "paytm" to setOf("paytm.com", "paytmbank.com"),
            "phonepe" to setOf("phonepe.com"),
            "gpay" to setOf("google.com", "pay.google.com"),
            "incometax" to setOf("incometax.gov.in", "incometaxindia.gov.in"),
            "indiapost" to setOf("indiapost.gov.in"),
            "uidai" to setOf("uidai.gov.in"),
            "kseb" to setOf("kseb.in")
        )
        val validHosts = officialDomains[brand] ?: return false
        return validHosts.any { host == it || host.endsWith(".$it") }
    }
}
