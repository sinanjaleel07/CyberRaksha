package com.example.engine

import com.example.data.model.ThreatCategory
import com.example.data.model.ThreatFinding
import com.example.data.model.ThreatSeverity

object TextPatternAnalyzer {

    // 1. Urgency & Account Suspension Patterns
    private val URGENCY_PATTERNS = listOf(
        Regex("(?i)\\b(electricity|power)\\s+(will\\s+be\\s+)?(disconnected|cut\\s*off|suspended)\\b"),
        Regex("(?i)\\b(tonight|immediately|within\\s+\\d+\\s*(hours?|hrs?|mins?))\\b"),
        Regex("(?i)\\b(account\\s+(blocked|suspended|deactivated|frozen))\\b"),
        Regex("(?i)\\b(pan\\s*(card)?\\s*(not\\s+updated|expired|blocked))\\b"),
        Regex("(?i)\\b(kyc\\s+(expired|pending|verification\\s+failed|update\\s+mandatory))\\b"),
        Regex("(?i)\\b(arrest\\s+warrant|police\\s+cyber\\s+cell|court\\s+order|customs\\s+parcel)\\b"),
        // Malayalam Urgency patterns
        Regex("വൈദ്യുതി\\s*വിച്ഛേദിക്കും"),
        Regex("അക്കൗണ്ട്\\s*ബ്ലോക്ക്\\s*ചെയ്യപ്പെട്ടു"),
        Regex("ഉടൻ\\s*പുതുക്കുക"),
        Regex("കെ\\.വൈ\\.സി\\s*പുതുക്കുക"),
        Regex("പോലീസ്\\s*അറസ്റ്റ്\\s*വാറണ്ട്")
    )

    // 2. OTP & PIN Stealing Patterns
    private val OTP_PIN_PATTERNS = listOf(
        Regex("(?i)\\b(share|send|forward|tell)\\s+(this\\s+)?(otp|one\\s*time\\s*password|verification\\s*code|pin)\\b"),
        Regex("(?i)\\b(enter|provide)\\s+(your\\s+)?(upi\\s*pin|atm\\s*pin)\\s+(to\\s+receive|for\\s+credit)\\b"),
        Regex("(?i)\\b(do\\s+not\\s+share.*executive\\s+calling)\\b"),
        Regex("(?i)\\b(read\\s+out\\s+the\\s+code)\\b"),
        // Malayalam OTP patterns
        Regex("ഓടിപി\\s*(ഷെയർ|നൽകുക|പറയുക)"),
        Regex("പിൻ\\s*നമ്പർ\\s*(നൽകുക|അടിക്കുക)")
    )

    // 3. Financial Phishing / Fake Reward Patterns
    private val FINANCIAL_LURES = listOf(
        Regex("(?i)\\b(you\\s+have\\s+won|lottery\\s+winner|prize\\s+money)\\b"),
        Regex("(?i)\\b(cashback\\s+(credited|approved|pending|claim))\\b"),
        Regex("(?i)\\b(refund\\s+(processed|pending|claim\\s+now))\\b"),
        Regex("(?i)\\b(part[ -]?time\\s+job|earn\\s+\\d+[k0-9]+\\s*(per|/)?\\s*day)\\b"),
        Regex("(?i)\\b(telegram\\s+task|like\\s+youtube\\s+videos\\s+and\\s+earn)\\b"),
        Regex("(?i)\\b(income\\s*tax\\s*refund|reward\\s*points\\s*expiring)\\b"),
        // Malayalam Financial patterns
        Regex("ലോട്ടറി\\s*(അടിച്ചു|വിജയി)"),
        Regex("ക്യാഷ്ബാക്ക്\\s*(ലഭിച്ചു|ക്ലെയിം)"),
        Regex("റീഫണ്ട്\\s*ലഭിക്കാൻ")
    )

    fun analyzeText(text: String): List<ThreatFinding> {
        val findings = mutableListOf<ThreatFinding>()

        // 1. Check OTP / PIN Theft (Highest severity)
        for (pattern in OTP_PIN_PATTERNS) {
            val match = pattern.find(text)
            if (match != null) {
                findings.add(
                    ThreatFinding(
                        ruleId = "TEXT_OTP_PIN_THEFT",
                        category = ThreatCategory.OTP_PIN_THEFT,
                        severity = ThreatSeverity.CRITICAL,
                        title = "Critical OTP / PIN Harvest Indicator",
                        matchedContent = match.value,
                        explanation = "Requesting an OTP or asking a user to enter a UPI PIN to receive money is a classic signature of financial cyber fraud. In UPI, PIN is strictly entered ONLY to SEND money, never to receive money.",
                        recommendedAction = "NEVER disclose OTP or enter UPI PIN. Cease all communication with the sender.",
                        scoreContribution = 55
                    )
                )
                break
            }
        }

        // 2. Check Urgency / Coercion Tactics
        for (pattern in URGENCY_PATTERNS) {
            val match = pattern.find(text)
            if (match != null) {
                findings.add(
                    ThreatFinding(
                        ruleId = "TEXT_URGENCY_SCARE_TACTIC",
                        category = ThreatCategory.URGENCY_SCAM,
                        severity = ThreatSeverity.HIGH,
                        title = "Psychological Pressure & Scare Tactic",
                        matchedContent = match.value,
                        explanation = "Scammers manufacture artificial panic (e.g. power disconnection tonight, immediate account freeze, fake police summons) to rush victims into acting without verifying.",
                        recommendedAction = "Do not panic. Call the official electricity board or bank customer helpline independently to verify.",
                        scoreContribution = 35
                    )
                )
                break
            }
        }

        // 3. Check Financial Lures & Telegram Work Scams
        for (pattern in FINANCIAL_LURES) {
            val match = pattern.find(text)
            if (match != null) {
                findings.add(
                    ThreatFinding(
                        ruleId = "TEXT_FINANCIAL_LURE",
                        category = ThreatCategory.FINANCIAL_PHISHING,
                        severity = ThreatSeverity.HIGH,
                        title = "Financial Bait / Part-time Task Scam",
                        matchedContent = match.value,
                        explanation = "Promises of instant cashback, unclaimed refunds, lotteries, or high-paying daily Telegram tasks are standard initial lures to solicit personal info or advance fees.",
                        recommendedAction = "Ignore unprompted offers. Genuine companies do not distribute unrequested cashback via random messaging links.",
                        scoreContribution = 30
                    )
                )
                break
            }
        }

        // 4. Check Direct APK Payload in Text
        val apkMatch = Regex("(?i)\\b([a-zA-Z0-9_\\-]+\\.apk)\\b").find(text)
        if (apkMatch != null) {
            findings.add(
                ThreatFinding(
                    ruleId = "TEXT_APK_PAYLOAD_LURE",
                    category = ThreatCategory.SUSPICIOUS_PAYLOAD,
                    severity = ThreatSeverity.CRITICAL,
                    title = "External APK Payload Solicitation",
                    matchedContent = apkMatch.value,
                    explanation = "The message instructs installing a standalone .apk package (${apkMatch.value}) outside Google Play. Fraudulent APKs often contain banking trojans, SMS stealers, or RAT payloads.",
                    recommendedAction = "Do NOT download or sideload this APK package. Only install apps from the official Google Play Store.",
                    scoreContribution = 50
                )
            )
        }

        return findings
    }
}
